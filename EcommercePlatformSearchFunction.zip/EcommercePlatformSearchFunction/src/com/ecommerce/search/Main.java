package com.ecommerce.search;

import java.util.Arrays;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        Product[] products = {
            new Product(1, "Laptop", "Electronics"),
            new Product(2, "Shoes", "Fashion"),
            new Product(3, "Book", "Education"),
            new Product(4, "Phone", "Electronics")
        };

        // Linear Search
        int linearIndex = SearchOperations.linearSearch(products, "Phone");
        if (linearIndex != -1) {
            System.out.println("Linear Search: Phone found in position " + (linearIndex + 1));
        } else {
            System.out.println("Linear Search: Phone not found.");
        }

        // Sort products by name for Binary Search
        Arrays.sort(products, Comparator.comparing(p -> p.productName.toLowerCase()));

        // Binary Search
        int binaryIndex = SearchOperations.binarySearch(products, "Phone");
        if (binaryIndex != -1) {
            System.out.println("Binary Search: Phone found in sorted position " + (binaryIndex + 1));
        } else {
            System.out.println("Binary Search: Phone not found.");
        }
    }
}
