package com.factory.documents;

public abstract class DocumentFactory {
    public abstract Document createDocument();
}
