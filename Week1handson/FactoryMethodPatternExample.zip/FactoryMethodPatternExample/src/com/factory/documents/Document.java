package com.factory.documents;

public interface Document {
	void open();
}
