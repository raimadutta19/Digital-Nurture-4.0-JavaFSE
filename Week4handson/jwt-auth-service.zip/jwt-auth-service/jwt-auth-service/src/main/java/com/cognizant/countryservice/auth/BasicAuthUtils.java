package com.cognizant.countryservice.auth;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class BasicAuthUtils {

    /** Simple value object for the pair */
    public record Creds(String username, String password) {}

    public static Creds extract(jakarta.servlet.http.HttpServletRequest request) {
        String header = request.getHeader("Authorization");
        if (header == null || !header.startsWith("Basic "))
            throw new IllegalArgumentException("Missing or invalid Basic header");

        String base64 = header.substring(6);
        String decoded = new String(
                Base64.getDecoder().decode(base64),
                StandardCharsets.UTF_8);

        int colon = decoded.indexOf(':');
        if (colon < 0) throw new IllegalArgumentException("Malformed credentials");

        return new Creds(decoded.substring(0, colon), decoded.substring(colon + 1));
    }
}
