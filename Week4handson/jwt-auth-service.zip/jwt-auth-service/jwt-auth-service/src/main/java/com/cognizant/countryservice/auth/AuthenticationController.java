package com.cognizant.countryservice.auth;

import org.springframework.http.ResponseEntity;
import com.cognizant.countryservice.auth.TokenService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.servlet.http.HttpServletRequest;

@RestController
public class AuthenticationController {

    private final TokenService tokenService;

    public AuthenticationController(TokenService tokenService) {
        this.tokenService = tokenService;
    }

    @GetMapping("/authenticate")
    public ResponseEntity<TokenResponse> authenticate(HttpServletRequest request) {
        var creds = BasicAuthUtils.extract(request);   // username & password
        tokenService.verify(creds);                    // raises on bad creds
        String jwt = tokenService.generate(creds.username());
        return ResponseEntity.ok(new TokenResponse(jwt));
    }

    /** Small record = JSON body {"token":"..."} */
    record TokenResponse(String token) {}
}
