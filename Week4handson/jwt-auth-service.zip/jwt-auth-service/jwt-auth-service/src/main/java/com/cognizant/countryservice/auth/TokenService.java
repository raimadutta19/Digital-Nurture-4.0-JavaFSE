package com.cognizant.countryservice.auth;

import java.time.Instant;
import java.util.Date;

import javax.crypto.SecretKey;

import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.security.Keys;

@Service
public class TokenService {

    private final AuthenticationManager authManager;
    private final SecretKey key = Keys.hmacShaKeyFor(
        // 32‑byte (256‑bit) key minimum – move to config in production
        "change‑this‑to‑a‑real‑256‑bit‑secret‑key‑please".getBytes());

    public TokenService(AuthenticationManager authManager) {
        this.authManager = authManager;
    }

    /** Delegates credential‑check to Spring Security */
    public void verify(BasicAuthUtils.Creds creds) {
        var auth = new UsernamePasswordAuthenticationToken(
                       creds.username(), creds.password());
        authManager.authenticate(auth); // throws BadCredentialsException if wrong
    }

    public String generate(String username) {
        Instant now = Instant.now();
        return Jwts.builder()
                   .setSubject(username)
                   .setIssuedAt(Date.from(now))
                   .setExpiration(Date.from(now.plusSeconds(600))) // 10 min
                   .signWith(key)
                   .compact();
    }
}
