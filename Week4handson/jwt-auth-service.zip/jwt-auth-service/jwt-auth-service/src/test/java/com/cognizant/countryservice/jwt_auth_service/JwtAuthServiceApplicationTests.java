package com.cognizant.countryservice.jwt_auth_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtAuthServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
