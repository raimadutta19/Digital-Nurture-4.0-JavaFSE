package com.cognizant.countryservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCountryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
