package com.example.junit;

import org.junit.Before;
import org.junit.After;
import org.junit.Test;
import static org.junit.Assert.*;

public class AaaPatternTest {

    private Calculator calc;

    // Setup method runs before every @Test
    @Before
    public void setUp() {
        calc = new Calculator();
        System.out.println("Setup complete");
    }

    // Teardown method runs after every @Test
    @After
    public void tearDown() {
        System.out.println("Test finished");
    }

    @Test
    public void testAddition_AAA() {
        // Arrange
        int a = 10;
        int b = 5;

        // Act
        int result = calc.add(a, b);

        // Assert
        assertEquals(15, result);
    }

    @Test
    public void testSubtraction_AAA() {
        int result = calc.subtract(10, 5);
        assertEquals(5, result);
    }
}
