package com.example;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ParameterizedLoggingExample {
    private static final Logger logger = LoggerFactory.getLogger(ParameterizedLoggingExample.class);

    public static void main(String[] args) {
        String username = "Raima";
        int loginAttempts = 3;
        boolean isLocked = true;

        logger.info("User {} has attempted to login {} times.", username, loginAttempts);
        logger.warn("Account locked status for user {}: {}", username, isLocked);
        logger.error("An error occurred for user {} after {} failed attempts.", username, loginAttempts);
    }
}
