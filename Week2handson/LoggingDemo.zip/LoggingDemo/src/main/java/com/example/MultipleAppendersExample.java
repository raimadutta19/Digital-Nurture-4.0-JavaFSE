package com.example;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MultipleAppendersExample {
    private static final Logger logger = LoggerFactory.getLogger(MultipleAppendersExample.class);

    public static void main(String[] args) {
        logger.info("This message goes to both console and file.");
        logger.debug("This is a debug message.");
        logger.warn("This is a warning!");
        logger.error("This is an error log entry.");
    }
}
