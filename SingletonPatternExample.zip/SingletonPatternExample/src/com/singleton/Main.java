package com.singleton;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Logger log1 = Logger.getInstance();
        Logger log2 = Logger.getInstance();
        
        log1.log("This is from log1");
        System.out.println(log1.hashCode());
        
        log2.log("This is from log2");
        System.out.println(log2.hashCode());//checking the hashcodes are same or not
        
        
        //to check if (log1 == log2)
        System.out.println(log1.equals(log2));

	}

}
