package com.financial.forecasting;

public class ForecastCalculator {

    // Recursive method
    public double futureValueRecursive(double pv, double rate, int years) {
        if (years == 0) {
            return pv;
        }
        return futureValueRecursive(pv * (1 + rate), rate, years - 1);
    }

    // Iterative method
    public double futureValueIterative(double pv, double rate, int years) {
        for (int i = 0; i < years; i++) {
            pv *= (1 + rate);
        }
        return pv;
    }
}
