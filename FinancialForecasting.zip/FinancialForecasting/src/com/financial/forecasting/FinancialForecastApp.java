package com.financial.forecasting;

public class FinancialForecastApp {

    public static void main(String[] args) {
        double presentValue = 10000;
        double growthRate = 0.05;
        int years = 5;

        ForecastCalculator calculator = new ForecastCalculator();

        double forecastRecursive = calculator.futureValueRecursive(presentValue, growthRate, years);
        double forecastIterative = calculator.futureValueIterative(presentValue, growthRate, years);

        System.out.println("Future Value (Recursive): " + forecastRecursive);
        System.out.println("Future Value (Iterative): " + forecastIterative);
    }
}
