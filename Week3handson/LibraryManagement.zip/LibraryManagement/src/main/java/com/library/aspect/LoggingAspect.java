package com.library.aspect;

import org.aspectj.lang.JoinPoint;

public class LoggingAspect {

    // ✅ Before advice
    public void logBefore(JoinPoint joinPoint) {
        System.out.println("➡️ [LOG] Before method: " + joinPoint.getSignature().getName());
    }

    // ✅ After advice
    public void logAfter(JoinPoint joinPoint) {
        System.out.println("⬅️ [LOG] After method: " + joinPoint.getSignature().getName());
    }
}
