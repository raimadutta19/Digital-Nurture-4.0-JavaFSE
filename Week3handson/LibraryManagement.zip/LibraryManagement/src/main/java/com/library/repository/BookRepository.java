package com.library.repository;

import org.springframework.stereotype.Repository;

@Repository  // ✅ Marks this as a repository component
public class BookRepository {
    public void saveBook(String bookName) {
        System.out.println("Book saved: " + bookName);
    }
}
