package com.example;

import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import static org.mockito.ArgumentMatchers.*;

public class MyServiceTest_ArgumentMatching {

    interface Logger {
        void log(String level, String message);
    }

    @Test
    public void testArgumentMatching() {
        Logger mockLogger = mock(Logger.class);

        mockLogger.log("INFO", "System started");

        // Verify it was called with exact arguments
        verify(mockLogger).log(eq("INFO"), anyString());
    }
}
