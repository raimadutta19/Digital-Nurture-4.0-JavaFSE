package com.example;

import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class MyServiceTest_MultipleReturns {

    interface ExternalApi {
        String getStatus();
    }

    @Test
    public void testMultipleReturns() {
        ExternalApi mockApi = mock(ExternalApi.class);

        when(mockApi.getStatus())
            .thenReturn("Loading")
            .thenReturn("Ready");

        assertEquals("Loading", mockApi.getStatus());
        assertEquals("Ready", mockApi.getStatus());
    }
}
