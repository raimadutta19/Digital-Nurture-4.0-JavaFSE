package com.example;

import org.junit.jupiter.api.Test;
import org.mockito.InOrder;

import static org.mockito.Mockito.*;

public class MyServiceTest_InteractionOrder {

    interface Processor {
        void stepOne();
        void stepTwo();
    }

    @Test
    public void testInteractionOrder() {
        Processor mockProcessor = mock(Processor.class);

        mockProcessor.stepOne();
        mockProcessor.stepTwo();

        InOrder inOrder = inOrder(mockProcessor);
        inOrder.verify(mockProcessor).stepOne();
        inOrder.verify(mockProcessor).stepTwo();
    }
}
