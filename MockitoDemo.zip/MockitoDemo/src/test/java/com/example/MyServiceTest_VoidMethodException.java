package com.example;

import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class MyServiceTest_VoidMethodException {

    interface Cleaner {
        void clean() throws RuntimeException;
    }

    @Test
    public void testVoidMethodException() {
        Cleaner mockCleaner = mock(Cleaner.class);

        // Stub void method to throw exception
        doThrow(new RuntimeException("Cleaning failed")).when(mockCleaner).clean();

        Exception exception = assertThrows(RuntimeException.class, () -> {
            mockCleaner.clean();
        });

        assertEquals("Cleaning failed", exception.getMessage());

        verify(mockCleaner).clean();
    }
}
