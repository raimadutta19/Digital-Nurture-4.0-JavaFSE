package com.example;

import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;

public class MyServiceTest_VerifyInteraction {

    @Test
    public void testVerifyInteraction() {
        // Step 1: Create mock object
        ExternalApi mockApi = mock(ExternalApi.class);

        // Step 2: Use the mock in the service
        MyService service = new MyService(mockApi);
        service.fetchData(); // internally calls mockApi.getData()

        // Step 3: Verify the interaction happened
        verify(mockApi).getData();
    }
}
