package com.example;

import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;

public class MyServiceTest_VoidMethod {

    interface Notifier {
        void send(String message);
    }

    @Test
    public void testVoidMethod() {
        Notifier mockNotifier = mock(Notifier.class);

        // No need to stub unless you want to suppress side effects
        mockNotifier.send("Hello");

        // Verify it was called
        verify(mockNotifier).send("Hello");
    }
}
